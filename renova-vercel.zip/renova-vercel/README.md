# ReNova — mise en ligne sur Vercel

Ce dossier contient tout le site dans un seul fichier, `index.html` (style, scripts et logo intégrés). Il n'y a aucun sous-dossier à envoyer.

| Fichier | Rôle |
| --- | --- |
| `index.html` | Le site complet |
| `vercel.json` | Indique à Vercel que c'est un site statique, sans commande de build |
| `README.md` | Ce mode d'emploi |

## Méthode 1 — Mettre à jour le site existant (via GitHub)

1. Ouvrez votre dépôt GitHub relié à Vercel.
2. **Add file › Upload files**, puis glissez les fichiers `index.html` et `vercel.json`. Ils remplacent les anciens.
3. **Commit changes**. Vercel republie automatiquement en une minute environ.

## Méthode 2 — Nouveau projet

1. Sur https://github.com, créez un dépôt vide (par exemple `renova`).
2. **Add file › Upload files**, glissez les trois fichiers de ce dossier, puis **Commit changes**.
3. Sur https://vercel.com/new, cliquez sur **Import** à côté de ce dépôt, laissez **Framework Preset : Other**, puis **Deploy**.

## Vérifier après la mise en ligne

- Le menu (Accueil, Carte, Outils…) s'affiche en haut de la page.
- Sur la page **Carte**, les rues de Liège apparaissent sous les épingles (fond Esri, sans clé ; OpenStreetMap en secours). Une connexion internet est nécessaire pour le fond de carte.
- Connexion › « Continuer en tant que Julie » permet de tester un échange complet.

## Modifier le site plus tard

Le code source lisible (fichiers CSS et JavaScript séparés) est dans le dossier `renova-site` fourni séparément. Après une modification, il faut reconstruire ce fichier unique ou demander une nouvelle version.
